`timescale 1ns/1ps
module tb;
logic clk=0,rst_n=0,sleep_req,wake_req,pwr_good;
logic pwr_en,iso_en,retain_en,active;

power_island_controller dut(.*);

always #5 clk=~clk;

initial begin
  sleep_req=0; wake_req=0; pwr_good=0;
  #20 rst_n=1;
  wake_req=1; #10 wake_req=0;
  #20 pwr_good=1;
  #20 sleep_req=1; #10 sleep_req=0;
  #30 wake_req=1; #10 wake_req=0;
  #20 pwr_good=1;
  #50 $finish;
end

initial begin
  $dumpfile("wave.vcd");
  $dumpvars(0,tb);
end
endmodule
