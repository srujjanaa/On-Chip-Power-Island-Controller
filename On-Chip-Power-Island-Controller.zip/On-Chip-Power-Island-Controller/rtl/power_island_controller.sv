module power_island_controller(
    input  logic clk,
    input  logic rst_n,
    input  logic sleep_req,
    input  logic wake_req,
    input  logic pwr_good,
    output logic pwr_en,
    output logic iso_en,
    output logic retain_en,
    output logic active
);

typedef enum logic[1:0] {OFF,POWERING,ON,SLEEP} state_t;
state_t state,next;

always_ff @(posedge clk or negedge rst_n)
  if(!rst_n) state<=OFF;
  else state<=next;

always_comb begin
  next=state;
  unique case(state)
    OFF: if(wake_req) next=POWERING;
    POWERING: if(pwr_good) next=ON;
    ON: if(sleep_req) next=SLEEP;
    SLEEP: if(wake_req) next=POWERING;
  endcase
end

always_comb begin
  pwr_en    = (state!=OFF);
  iso_en    = (state==OFF);
  retain_en = (state==SLEEP);
  active    = (state==ON);
end
endmodule
