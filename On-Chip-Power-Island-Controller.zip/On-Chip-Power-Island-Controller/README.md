# On-Chip Power Island Controller

Educational RTL project demonstrating a simple power island controller for a multi-power-domain SoC.

## Features
- FSM-based controller
- Sleep / Wake control
- Isolation control
- State retention enable
- Power-good acknowledgement
- SystemVerilog RTL
- Self-checking testbench

## Folder Structure
- rtl/: RTL source
- tb/: Testbench
- docs/: Documentation
- sim/: Simulation scripts
