# Example
vlogan ../rtl/power_island_controller.sv ../tb/tb_power_island_controller.sv
vcs tb
./simv
